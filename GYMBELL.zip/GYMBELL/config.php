<?php
//untuk membuat sambungan dari pangkalan data dengan hasil paparan
    $conn = mysqli_connect("localhost","root","","gymbell");
?>